--INDEX for detail look at course create index 'name_idx' on table_name(column)

create index mon_idx
on months_values(MM);

--drop index
drop index if exists mon_idx;

--rename index
alter index if exists mon_idx
rename to new_mon_idx; 