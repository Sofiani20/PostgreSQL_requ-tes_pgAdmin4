
select a.*,
	   customer.customer_name,
	   customer.age as customer_age
from (select sales.*,
	  		 product.product_name,
	         product.category as product_category
	  from sales 
	  left join product
	  on sales.product_id=product.product_id) as a
left join customer
on a.customer_id=customer.customer_id;