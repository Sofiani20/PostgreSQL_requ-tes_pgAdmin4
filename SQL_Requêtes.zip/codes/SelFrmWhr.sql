select fisrt_name from Customers_table;
select fisrt_name, last_name from Customers_table;
select * from customers_table;
select distinct fisrt_name from customers_table;
select distinct * from customers_table;
copy Customers_table from 'C:\Program Files\PostgreSQL\13\data\Data_copy\copy.csv'
delimiter ',' csv header;
select distinct * from customers_table;

select fisrt_name, age
from customers_table 
where age>=25;

select distinct fisrt_name 
from customers_table 
where age>=25;

select * 
from customers_table 
where fisrt_name='Gee';

select fisrt_name, last_name, age
from customers_table
where age<30 and age>20;

select fisrt_name, last_name, age
from customers_table
where age<30 or age<20;

select fisrt_name, last_name, age
from customers_table
where not age=25;

