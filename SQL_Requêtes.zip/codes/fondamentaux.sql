create table Science_class(
Enrollment_no int, Name varchar, Science_marks int
);
insert into Science_class (Enrollment_no, Name, Science_marks) values
(1,'Popeye',33),
(2,'Olive',54),
(3,'Brutus',98);

copy Science_class from 'C:\Program Files\PostgreSQL\13\data\Data_copy\Student.csv'
delimiter ',' csv header;

select * 
from science_class

select Name, science_marks
from science_class
where science_marks>60; 

select *
from science_class
where science_marks<60 and science_marks>35; 

select *
from science_class
where science_marks>=60 or science_marks<=35; 


