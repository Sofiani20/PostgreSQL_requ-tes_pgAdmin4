--LEFT JOIN
/*Dans le langage SQL, la commande LEFT JOIN (aussi appelée LEFT OUTER JOIN) est un type de jointure entre 2 tables.
Cela permet de lister tous les résultats de la table de gauche (left = gauche) même s'il n'y a pas de correspondance
dans la deuxième tables*/
select 
		a.order_line,
		a.product_id,
		a.customer_id,
		a.sales,
		b.customer_name,
		b.age
from sales_2015 as a 
left join customer_20_60 as b
on a.customer_id=b.customer_id
order by customer_id asc;