-- INNER JOIN 

/*jointure interne, cette commande retourne les enregistrements
lorsqu'il y a au moins une ligne dans chaque colonne qui correspond
à la condition*/

select 
		a.order_line,
		a.product_id,
		a.customer_id,
		a.sales,
		b.customer_name,
		b.age
from sales_2015 as a 
inner join customer_20_60 as b
on a.customer_id=b.customer_id
order by customer_id asc;
		
		