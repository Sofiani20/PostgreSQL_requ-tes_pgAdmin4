select *
from customer_20_60;
select *
from sales_2015;

select 
    a.state,
	sum(b.sales) as total_of_sales
from customer_20_60 as a
left join sales_2015 as b
on a.customer_id=b.customer_id
group by a.state
order by total_of_sales;

select 
    a.state,
	b.sales,
	a.customer_id
from customer_20_60 as a
left join sales_2015 as b
on a.customer_id=b.customer_id
order by a.state;


select *
from product;

select 
	product.product_id,
	product.product_name,
	product.category,
	sum(sales.sales) as total_sold
from product
left join sales
on product.product_id=sales.product_id
group by product.product_id
order by total_sold;
	



	