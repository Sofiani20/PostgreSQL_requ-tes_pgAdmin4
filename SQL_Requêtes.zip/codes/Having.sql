select region, count(customer_id) as "number_of_customers"
from customer
where customer_name like 'A%'
group by region
having count(customer_id)>=2;


/* HAVING is used to specify condition on aggregate function whereas 
WHERE is used for conditions on no-agregate columns*/