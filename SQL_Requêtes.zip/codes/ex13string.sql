select product_id,
       product_name,
	   length(product_name)
from product
order by length(product_name) desc;

select product_name, 
	   sub_category,
	   category,
	   product_name||', '|| sub_category ||', '||category as product_details
from product;

select product_id,
	   substring(ltrim(product_id,' ') for 3) as part_1_id,
	   substring(ltrim(product_id,' ')from 5 for 2) as part_2_id,
	   substring(ltrim(product_id,' ') from 8) as part_3_id,
	   product_name
from product;
	   
select sub_category,
	   string_agg(product_name, '|||')
from product
where sub_category in ('Chairs','Tables')
group by sub_category;