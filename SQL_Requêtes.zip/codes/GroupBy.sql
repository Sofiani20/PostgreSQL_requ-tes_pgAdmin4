select region, count(customer_id) as "nombre_of_customer_b_region"
from customer
group by region;

select product_id, sum(quantity) as "quantity_sold"
from sales
group by product_id
order by quantity_sold desc;

select customer_id,
min(sales) as "min_sales",
max(sales) as "max_sales",
sum(sales) as "sum_sales",
avg(sales) as "average_sales"
from sales
group by customer_id
order by sum_sales desc
limit 5;

select region,state, count(customer_id) as "nombre_of_customer_b_region"
from customer
group by region,state;