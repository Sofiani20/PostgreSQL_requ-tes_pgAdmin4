--TRUNCATE deletes all records of a tables, by using the option CASCADE it will delete also the records
--of any table related to the first table
-- RESTRICT remove only the first table rows even if this this table is related to another
-- ONLY option is used when we want to delete only the specified table and to keep descending tables
-- of this table

select * from customer_20_60;
select * from sales_2015;

truncate only customer_20_60
restrict;

--same operation as
delete from customer_20_60;