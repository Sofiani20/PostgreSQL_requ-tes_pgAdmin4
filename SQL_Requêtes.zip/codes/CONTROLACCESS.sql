/* USER ACESS CONTROL */

create user Sofiani
with password 'sofianii'
valid until 'jan 1, 2021' -- or 'infinity'

-- to make more control to a database by using GRANT and REVOKE commands
/* if you want to give access to any particular command we use GRANT commands
otherwise when we want to revoke access we use REVOKE */
-- GRANT 'commands' ON 'object can be table or view' TO 'user'
-- REVOKE 'commands' ON 'object' FROM 'user'

grant all on product to sofiani; -- grant all commands
grant select, insert, delete on product to sofiani;
revoke all on product from sofiani; 
-- to check if grant or revoke works go the table properties

-- if we want to drop a user
revoke all on product from sofiani;
drop user sofiani;
/*if the user owns a database make sure to delete the database before drop the user*/

--renaming user name
alter user sofiani
rename to Sofiani_Mahamadou ;

--run a query against 'pg_user' table to retrieve informations about all users
select usename from pg_user ;
select * from pg_user ;

--run a query against 'pg_stat_activity' table to retrieve informations about logged in users
select usename
from pg_stat_activity;
select distinct usename
from pg_stat_activity;
select distinct * -- to see all activities
from pg_stat_activity;