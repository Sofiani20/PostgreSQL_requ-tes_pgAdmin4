-- case when is like if/else in c

select *,
case when age<30 then 'young'	
	 when age>60 then 'Senior citizen'
     else 'middle categories'
end as "age_categories"
from customer;