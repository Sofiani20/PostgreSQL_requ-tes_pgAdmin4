select sum(sales) as "total_sales_value"
from sales;

select count(customer_id) as "north_customers_number"
from customer
where (region='North') and (age between 20 and 30);

select avg(age) as "east_avg_age"
from customer
where region='East';


select min(age) as "min_age_from_philadelphia",
	   max(age) as "max_age_from_philadelphia"
from customer
where city='Philadelphia'