
-- UNION

/*La commande UNION de SQL permet de mettre bout-à-bout les résultats de plusieurs requêtes
utilisant elles-même la commande SELECT. C'est donc une commande qui permet de concaténer 
les résultats de 2 requêtes ou plus*/

/* nous souhaitoons avoir tous les id_cust présent dans nos deux tables*/
-- similar à la commande distinct
select customer_id -- col1, col2...
from sales_2015
union
select customer_id  -- col1 mm type que col1 du tab sales_2015 (reps.....) et même nbre de col
from customer_20_60