select *
from customer   --by default it orders by ascendant ordre ASC
where state ='California'
order by customer_name;
-- we obtain the same result as
select *
from customer   
where state ='California'
order by customer_name asc;
-- descendant order
select *
from customer   
where state ='California'
order by customer_name desc ;

select*
from customer
order by city asc, customer_name desc;

-- we can order by column number too!!!!!
select*
from customer
order by 2 asc;

select*
from customer
order by age desc
limit 15; --limit stat allows us to limit the numbre of rows resulted

--ex7
select order_id, discount
from sales
where discount>0
order by discount desc
limit 10;
