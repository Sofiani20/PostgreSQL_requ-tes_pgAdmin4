--to restore a db, create fisrt a db, then choose the option restore and follow
-- instruction, for backup you choose the option backup then give a file name
-- then the file type ...
select * from customer;
select * from product;
select * from sales;
