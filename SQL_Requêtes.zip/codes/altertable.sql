--adding or deleting a column, changing column name or type, make constraint
--is modifying the structure of table
-- for doing this we use ALTER TABLE command

-- adding new column called test which values's type is varchar max:255
alter table customers_table
add test_col varchar(255);

select * from customers_table;

-- dropping column from a table
alter table customers_table
drop test_col;

--changing a specify column data type
alter table customers_table
alter column age type varchar(255);

--changing column name
alter table customers_table
rename column email_id to cust_email;

-- make not null constraint
alter table customers_table
alter column cust_id set not null;
--lets try to insert a value that hasn't id
insert into customers_table
(fisrt_name, last_name, age, cust_email)
values ('IB','HK','21','hk@gmail.com');
-- we can drop the not null constraint by doing:
alter table customers_table
alter column cust_id drop not null;

--adding checking constraint
alter table customers_table
add constraint cust_id check (cust_id>0);
insert into customers_table
(cust_id,fisrt_name, last_name, age, cust_email)
values (-1,'ISAT','ASSOU','23','assou@gmail.com');

--now lets add primary and foreign key to our table
alter table customers_table
add primary key (cust_id); -- it returns error because we have a null id in the table
                           -- whereas primary key cannot contain null value
-- to solve this  we are going to drop this row
delete from customers_table
where cust_id is null;
insert into customers_table
(cust_id,fisrt_name, last_name, age, cust_email)
values (1,'ISAT','ASSOU','23','assou@gmail.com');
select* from customers_table


