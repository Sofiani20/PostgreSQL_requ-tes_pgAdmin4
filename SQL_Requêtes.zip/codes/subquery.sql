--SUBQUERIES

/*A Subquery or Inner query or a Nested query is a query within another SQL query
it can be used in select, where, from clause and also wiyhin a subquery*/

-- subquey in a where clause
select *
from sales
where customer_id in (select customer_id
					  from customer
					  where age>60)
select customer_id
from customer
where age>60

select distinct customer_id, count(customer_id)
from sales
where customer_id in (select customer_id
					  from customer
					  where age>60) 
group by  customer_id

-- subquery with from clause
/*lets say we want to find out the quantity of each product sold*/
select 
		a.product_id,
		a.product_name,
		a.category,
		b.quantity
from product as a
left join (select distinct product_id, sum(quantity) as quantity
		  from sales
		  group by product_id) as b
on a.product_id= b.product_id
order by b.quantity desc;

-- subquery within a select clause
select customer_id, order_line,
		(select customer_name from customer where sales.customer_id=customer.customer_id)
from sales
order by customer_id;


