-- PATTERN MATCHING:nous pouvons définir la correspondance de modèle comme 
-- une méthode pour identifier la chaîne conforme à un format donné.
-- methods are: LIKE statements, SIMILAR TO statements, ~(Regular expression) or REGEX functions


