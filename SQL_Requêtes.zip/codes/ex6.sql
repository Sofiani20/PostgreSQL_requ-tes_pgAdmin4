select distinct city, region
from customer
where region in ('North','East');

select order_line, sales
from sales
where sales between 100 and 500;

select *
from customer
where customer_name like '% ____';


