/* STRING FUNCTIONS*/

-- length(): return the number of string's characters, spaces are also counted
select customer_name, length(customer_name) as length_customer_name
from customer
where length(customer_name) >10
order by length_customer_name;

-- UPPER() and LOWER(): can be useful when you want to match strings
select upper('Start-Tech')
select lower('Start-Tech')

-- REPLACE(column,'string we want to replace','new string')
select customer_name, country, replace(lower(country),'united states', 'US')
from customer;
select country
from customer;
--if we want to have changing in our table we use UPDATE
