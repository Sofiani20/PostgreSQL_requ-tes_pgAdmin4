select * from customer;
select * from product;
select * from sales;
--in statement
select * 
from customer
where city in ('Seattle','Philadelphia');

-- we get same thing with
select * 
from customer
where city='Seattle' or city='Philadelphia';

-- between statement
select * 
from customer
where age between 20 and 30
--samething 
select * 
from customer
where age>=20 and age<=30;

--not between
select * 
from customer
where age not between 20 and 30;
-- same as
select * 
from customer
where age<20 and age>30;

/* we can also use between stat for dates*/
select * 
from sales
where ship_date between '2015-04-01' and '2016-04-01';

-- wildcards % and _
select *
from customer
where customer_name like 'J%'; --noms commençant paj J

select *
from customer
where customer_name like '%Nelson%'; --ayant Nelson dans leur nom

select *
from customer
where customer_name like '____%'; --name begining with four caractère after n'importe

select distinct city
from customer
where city not like 'S%';

select *
from customer
where customer_name like 'G\%';



