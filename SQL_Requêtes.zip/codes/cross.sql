-- CROSS JOIN

/* Dans la terminologie SQL, une opération dans laquelle le produit cartésien est formé à partir de deux tables
de base de données est appelée CROSS JOIN.Dans la pratique, les CROSS JOINs sont rarement utilisés 
en raison de l'ensemble des résultats non filtrés.  */

create table Months_values (MM integer);
create table Years_values (YYYY integer);

insert into Months_values 
values (01),(02),(03),(04),(05),(06),(07),(08),(09),(10),(11),(12)
insert into Years_values 
values (2011),(2012),(2013),(2014),(2015),(2016),(2017),(2018),(2019),(2020)

select *
from years_values
select *
from Months_values

select a.YYYY , b.MM
from Years_values as a, Months_values as b
order by a.YYYY, b.MM desc;


