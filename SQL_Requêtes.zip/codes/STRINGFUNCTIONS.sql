/* STRING FUNCTIONS*/

-- length(): return the number of string's characters, spaces are also counted
select customer_name, length(customer_name) as length_customer_name
from customer
where length(customer_name) >10
order by length_customer_name;

-- UPPER() and LOWER(): can be useful when you want to match strings
select upper('Start-Tech')
select lower('Start-Tech')

-- REPLACE(column,'string we want to replace','new string')
select customer_name, country, replace(lower(country),'united states', 'US')
from customer;
select country
from customer;
--if we want to have changing in our table we use UPDATE

/*Dans le langage SQL la fonction TRIM() permet de supprimer des caractères au début et en fin
d'une chaîne de caractère. Le plus souvent la fonction TRIM() permet de supprimer les caractères
invisibles, c'est-à-dire les caractères tels que l'espace, la tabulation, 
le retour à la ligne ou bien même le retour chariot*/

select trim(leading ' ' from ' Start-Tech ');
select trim(trailing ' ' from ' Start-Tech ');
select trim(' Start-Tech '); -- by the default the front and back spaces will be removed
select trim(both' ' from ' Start-Tech ');
select rtrim(' Start-Tech ',' '); --right trim remove at the end
select ltrim(' Start-Tech ',' '); --left trim remove at the top

-- concatenate by using || 
select customer_name,
		city||', '||state||', '||country as address
from customer;

--SUBSTRING: SUBSTRING(string [FROM start_position] [FOR length])
select customer_id,
	   customer_name,
	   substring (customer_id for 2) as cust_grp1--by défault the start is the begining of the string
from customer
where substring (customer_id for 2)='AB';

select customer_id,
	   customer_name,
	   substring (customer_id from 4 for 5) as cust_grpAB
from customer
where substring (customer_id for 2)='AB';

select customer_id,
	   customer_name,
	   substring (customer_id from 4) as cust_grp2
from customer
where substring (customer_id for 2) not like 'AB%';

-- STRING_AGG(expression, delimiter) will concatenate alll string in expression and insert the delimiter
--between each other
select order_id,
string_agg(product_id,','),
count(product_id) as number_of_product
from sales
group by order_id
order by length(string_agg(product_id,',')) desc;



