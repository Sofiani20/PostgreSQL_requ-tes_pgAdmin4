/* TABLESPACEs allow database administrators to define locations in a file system where the 
file representing database objects can be stored. they can be only created by the superuser of the
database. ordinary users could store objects in a location when superuser grants them
create command*/

create tablespace NewSpace 
location 'C:\Program Files\PostgreSQL\13\data\mon_stockage';

-- lets store new table in this tablespace
create table customer_test 
(i int) tablespace NewSpace;
select * --to see all tablespace created
from pg_tablespace;

/*set default_tablespace=NewSpace
create table second_table(test_column int)*/
