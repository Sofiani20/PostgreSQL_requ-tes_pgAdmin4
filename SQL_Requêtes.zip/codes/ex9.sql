select product_id, sum (sales) as total_sales,
sum (quantity) as total_quantity,
count (order_id),
min (sales) as min_sales,
max (sales) as max_sales,
avg (sales) as avg_sales_values
from sales
group by product_id
having sum (quantity)>10
order by total_sales desc
limit 10;