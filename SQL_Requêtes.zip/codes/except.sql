--EXCEPT

/*Dans le langage SQL la commande EXCEPT s'utilise entre 2 instructions pour récupérer les enregistrements de la 
première instruction sans inclure les résultats de la seconde requête. Si un même enregistrement
devait être présentdans les résultats des 2 syntaxes, ils ne seront pas présent dans le résultat final.*/

/*on souhaite extraire les id_cutomer qui sont dans la tab1, mais absent dans tab2!!*/
select customer_id
from sales_2015    -- table 1 !!
except 
select customer_id -- memes colonnes que dans le premier select
from customer_20_60-- table 2 !!

