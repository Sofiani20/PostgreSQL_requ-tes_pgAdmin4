select count(*)
from sales;

select count(order_line) as "Number of Product ordered",
count(distinct order_id) as "Number of Orders"
from sales
where customer_id='CG-12520';

select *
from sales
where customer_id='CG-12520';

select sum(profit) as "total profit"
from sales;

select sum(quantity) as "total quantity sold"
from sales
where product_id='FUR-TA-10000577';
select*
from sales
where product_id='FUR-TA-10000577';

select avg(age) as "average customer age"
from customer;

select avg(sales*0.1) as "average commission paid"
from sales;

select min(sales) as "june15_min_sale"
from sales
where order_date between '2015-06-01' and '2015-06-30';
-- to check this
select *
from sales
where order_date between '2015-06-01' and '2015-06-30'
order by sales asc;
-- the max
select max(sales) as "june15_max_sale"
from sales
where order_date between '2015-06-01' and '2015-06-30';
select sales
from sales
where order_date between '2015-06-01' and '2015-06-30'
order by sales desc;