/* MATHEMATICAL FUNCTIONS */

-- CEIL(relatif sup) AND FLOOR(partie entière) FUNCTIONS:
select order_line, sales, ceil(sales) as ceil_sales_values , floor(sales) as floor_sales_values
from sales;

-- RANDOM function retourn random numbers between 0(included) and 1(excluded)
-- we want random, random float in [10,50[ , int random in [10,50]
select random() as range_0_1, 
	   random()*(50-10)+10 as range_10_50,
	   floor(random()*(50-10+1))+10
	   
-- if you want the same random value being generated evry time
-- you use setseed(seed) function by changing seed arg we will get another set
select setseed(0.5)
select random()
select setseed(1)

--ROUND() function arrrondir
select order_line,sales, round(sales)
from sales;

--POWER(m,n) m exposant n
select power(age,2), age from customer;

-- exercice 14
select customer_id, random() as loterie
from customer
order by loterie desc
limit 5;

select
	sum(ceil(sales)), sum(floor(sales)), sum(round(sales))
from sales






