select customer_id as "Serial Number", age as customer_age, customer_name as name
from customer;