select *
from customers_table
where cust_id=2;

update customers_table
set last_name='Oké', age=17
where cust_id=2;

delete from customers_table
where cust_id=6 or age>30

delete from customers_table

