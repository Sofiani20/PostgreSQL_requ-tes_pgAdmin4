-- VIEW
/*VIEW is not a physical table, it is a virtual table created by a query joining one or more tables.
The difference between a view and a table is that views are definitions built on top of
other tables (or views), and do not hold data themselves. If data is changing in the
underlying table, the same change is reflected in the view. A view can be built on top
of a single table or multiple tables. It can also be built on top of another view*/

create or replace view logistics as
select a.order_line,
	   a.order_id,
	   b.customer_name,
	   b.city,
	   b.state,
	   b.country
from sales as a
left join customer as b
on a.customer_id=b.customer_id
order by a.order_line;

select *
from logistics;

-- dropping view
drop view logistics;

--updating view
update logistics
set country = 'US'
where country='United States'
-- if we want to update view see conditions in ressources even if it isn't advisable!!!


/*exercise 12*/
create or replace view Daily_Billing as
select order_line,
       product_id,
	   sales,
	   discount
from sales
where order_date='2014-01-03';

select *
from Daily_Billing;

select *
from sales
order by order_date

drop view if exists Daily_Billing;