/* JOIN is used when we wish to retrieve data
from more than 1 table!!!! */

/*to practice this statement lets create two tables
which will be two subset of sales table and customer table*/

/*creating table wiht only 2015 sales*/
create table sales_2015 as 
select * 
from sales
where ship_date between '2015-01-01' and '2015-12-31';
select count(*)
from sales_2015;
select count(distinct(customer_id))
from sales_2015;

/* Customers with age between 20 and 60*/
create table customer_20_60 as
select *
from customer
where age between 20 and 60;
select count(*)
from customer_20_60;








