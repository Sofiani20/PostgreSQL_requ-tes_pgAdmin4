/* TO_CHAR(value, format_mask) */

select sales, to_char(sales,'$9,999.99') --9999.99 veut dire 4 chiffres avant la virgule et 2 après
from sales;

select order_date, to_char(order_date,'MM/DD/YYYY') --convert date to string
from sales;

select order_date, to_char(order_date,'month/DAY/YYYY') --convert date to string
from sales;

/*TO_DATE(string,fromart_mask)*/
select to_date('2020/12/08','YYYY/MM/DD');
select to_date('20201208','YYYYMMDD');

/*TO_NUMBER(string,format_mask)*/
select to_number('1234.5','9999.99');
select to_number('$1,234.567','L9,999.99');
