-- CURRENT_DATE & CURRENT_TIME

--current_date will return the current date in the format 'YYYY-MM-DD'
--current_time will return the locale time int the format 'HH:MM:SS.GMT+TZ'

select current_date, current_time, current_time(1), current_time(3), current_timestamp;

--AGE(date1,date2)
select age('2000-10-04',current_date) -- if the second date isn't mentioned the current date will be used

select order_line, order_date, ship_date,
	   age(ship_date,order_date) as time_taken
from sales
order by time_taken desc;

-- EXTRACT function extracts parts from date extract('unit' from 'date')
select extract(day from current_date);
select extract(hour from current_timestamp);
-- difference between two dates in second
select order_date, ship_date,
extract(epoch from (ship_date-order_date))--epoch is used on date!!! whereas the # is integer so error!!
from sales;
-- lets correct this
select order_date, ship_date,
extract(epoch from age(ship_date,order_date)) as number_of_second_taken,
extract(epoch from age(ship_date,order_date))/60 as number_of_minute_taken,
extract(epoch from age(ship_date,order_date))/3600 as number_of_hour_taken,
extract(epoch from age(ship_date,order_date))/86400 as number_of_day_taken
from sales;


--exercise15
select extract(year from age('1939-04-06',current_date)) -- age in year
select extract(month from age('1939-04-06',current_date)) -- age in month
select extract(day from age('1939-04-06',current_date)) -- in day


select b.sub_category,
       extract(month from a.ship_date) as months,
	   extract(year from a.ship_date) as years,
       sum(a.sales) as monthly_sales
from sales as a
left join product as b
on a.product_id=b.product_id
where b.sub_category='Chairs'
group by years, months,b.sub_category
order by years;

